// 路由文件配置
import Vue from 'vue'
import Router from 'vue-router'

import index from '@/page/index'

//使用路由
Vue.use(Router)

const routers = [
	{
		path: '/',
		name: 'index',   //财务查询页
		component: index
	},
]

export default new Router({
  // mode: 'history',
  routes: routers
})
