<template>
  	<div class="index">
  		<h1 style="font-size: 40px;text-align: center;margin-top: 30vh;">Hello World!</h1>
  	</div>
</template>

<script>
import {
    getData,
    addData,
    getAddr
} from '@/api/api'

export default {
  	data () {
    	return {
      
    	}
  	},
  	created(){
    	this.$api.get('/api/Interview/getData.php').then(function(res){
            console.log(res)
        })
        getData().then(res=>{
            console.log(res);
        })

        addData(1,2,3,4,5,6,7,8,9,0).then(res=>{
            console.log(res);
        })

        getAddr().then(res=>{
            console.log(res);
        })
  	},
}
</script>

<style scoped>
	
</style>
