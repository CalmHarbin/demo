<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
  body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,span,i,a,p,pre,code,form,fieldset,legend,input,button,textarea,p,blockquote,th,td,table,header,footer,nav,aside{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  img{
    vertical-align: middle;
    max-width: 100%;
    height: auto;
    border:none;
  }
  body{
    width: 100%;
    overflow-x: hidden;
    font-size:14px;
    min-height: 100vh;
  }
  ul,li,ol{
    list-style: none;
  }
  h1,h2,h3,h4,h5,h6{
    font-weight: 300;
  }
  a{
    text-decoration: none;
  }
  a:hover{
    text-decoration: none;
  }
  .none{
    display: none!important;
  }
  table{ 
    border-collapse:collapse;
    border-spacing:0;
  }
</style>
