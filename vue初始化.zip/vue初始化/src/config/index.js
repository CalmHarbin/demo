//配置文件
const config = {
    serverUrl :"http://qy.sunjee.cn:8021",       	//服务器地址
}

export default config;