import axios from '@/api/index'
import config from '@/config/index'

//get获取数据
const getData=()=>new Promise(resolve=>{
    axios.get(config.serverUrl+'/api/Leave/GetList',{
        key:1,
        rows:4,
        page:1,
    }).then(res=>{
        resolve(res);
    })
})

//post提交数据
const addData=(userid,name,areaid,classid,leavetypeid,starttime,endtime,day,hour,content)=>new Promise(resolve=>{
    axios.post(config.serverUrl+'/api/Leave/Insert',{
       "userid": userid,
       "name": name,
       "areaid": areaid,
       "classid": classid,
       "leavetypeid": leavetypeid,
       "starttime": starttime,
       "endtime": endtime,
       "day": day,
       "hour": hour,
       "content": content
    }).then(res=>{
        resolve(res);
    })
})

//跨域请求
const getAddr=()=>new Promise(resolve=>{
    axios.get('/api/Interview/getData.php').then(res=>{
        resolve(res);
    })
})

export {
    getData,        //获取列表
    addData,        //提交数据
    getAddr,        //跨域请求
};