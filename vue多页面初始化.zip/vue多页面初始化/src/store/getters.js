const getters = {
  count: state => state.app.count,
  name: state => state.user.name,
};
export default getters;
