<template>
  <div>
    <p class="detail">detail Page</p>
  </div>
</template>
<script>
export default {

};
</script>
<style scoped>
.detail {
  font-size: 24px;
}
</style>
