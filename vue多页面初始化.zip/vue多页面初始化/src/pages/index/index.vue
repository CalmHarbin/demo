<template>
    <div class='index'>
        <p>Index Page</p>
        <div class="count">
            <span v-text='count'></span>
            <button @click="add">add count</button>
            <a href="./list.html">跳转到list</a>
            <a href="./detail.html">跳转到detail</a>
        </div>
        <img src="../../assets/logo.png" alt="">
    </div>
</template>
<script>

import { mapGetters, mapActions } from 'vuex';
import {
  getData,
  addData,
  getAddr
} from '@/api/api';

export default {
  name: 'index',
  computed: {
    ...mapGetters(['count'])
  },
  methods: {
    ...mapActions([
      'addCount'
    ]),
    add(){
      this.addCount({num: 10});
    }
  },
  created(){
    getData().then(res=>{
      console.log(res);
    });

    addData(1,2,3,4,5,6,7,8,9,0).then(res=>{
      console.log(res);
    });

    getAddr().then(res=>{
      console.log(res);
    });
  },

};
</script>
<style scoped>
  button{
    color: red;
  }
</style>
