<template>
  <div>
    <p class="list">List Page</p>
  </div>
</template>
<script>
export default {

};
</script>
<style scoped>
.list {
  font-size: 24px;
}
</style>
