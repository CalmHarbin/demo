import '@/css/style.css';

function fn(){
	var a=1;
	var fn2=()=>{
		alert(a);
	}
	fn2();
}
fn();